package com.snapdealgallery.places.model;

/**This interface used to reduce redundant use of code 
 * and works for server request and associated with WebServiceAsync Class
*/
public interface OnWebServiceProcess {
	void getServerValues(String response, int id, boolean isOk);
	void setServerError(int id, String msg);
}
