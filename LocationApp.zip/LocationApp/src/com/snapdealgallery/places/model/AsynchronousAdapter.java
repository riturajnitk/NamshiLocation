package com.snapdealgallery.places.model;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.sd.places.ui.R;
import com.snapdealgallery.places.ui.PlaceDetailsActivity;

/*
 * This adapter is used to asynchronously loading the place images to the listview. 
 */
public class AsynchronousAdapter extends BaseAdapter implements Filterable {

	private Context mContext;
	private ArrayList<GooglePlaceData> mGPlacesDataAL, filteredPlacesAL;
	private LayoutInflater inflater = null;
	public ImageLoader imageLoader;
	private PlaceNameFilter mPlacesFilter;
	
	public AsynchronousAdapter(Context mContext, ArrayList<GooglePlaceData> mGPlacesData) {
		this.mContext = mContext;
		this.mGPlacesDataAL = mGPlacesData;
		this.filteredPlacesAL = mGPlacesData;
		inflater = (LayoutInflater) mContext
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		imageLoader = new ImageLoader(mContext.getApplicationContext());
		
		getFilter();
	}
	
	public int getCount() {
		return filteredPlacesAL.size();
	}

	public Object getItem(int position) {
		return filteredPlacesAL.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		final ViewHolder holder;
        final GooglePlaceData user = (GooglePlaceData) getItem(position);
        
		if (convertView == null){
			convertView = inflater.inflate(R.layout.place_item, null);
			holder = new ViewHolder();
			holder.text = (TextView) convertView.findViewById(R.id.placename);
			holder.image = (ImageView) convertView.findViewById(R.id.placeicon);
			convertView.setTag(holder);
			
			convertView.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					String mPhotoRef = user.mReference;
					Intent mIntent = new Intent(mContext,
							PlaceDetailsActivity.class);
					mIntent.putExtra("PHOTOREF", mPhotoRef);
					mContext.startActivity(mIntent);
				}
			});
		}
		else{
			
	        holder = (ViewHolder) convertView.getTag();
		}
		
		holder.text.setText(user.mPlaceName);
		imageLoader.displayImage(user.mPlaceIcon, holder.image);
		return convertView;
	}

	static class ViewHolder {
        TextView text;
        ImageView image;
    }

	
	@Override
	public Filter getFilter() {
		if (mPlacesFilter == null) {
			mPlacesFilter = new PlaceNameFilter();
		}

		return mPlacesFilter;
	}

	private class PlaceNameFilter extends Filter {

		@Override
		protected FilterResults performFiltering(CharSequence constraint) {
			FilterResults placeFilerResults = new FilterResults();
			if (constraint != null && constraint.length() > 0) {
				ArrayList<GooglePlaceData> tempList = new ArrayList<GooglePlaceData>();

				for (GooglePlaceData mPlaceData : mGPlacesDataAL) {
		
					if (mPlaceData.mPlaceName.toLowerCase().contains(
							constraint.toString().toLowerCase())) {
						
						
						tempList.add(mPlaceData);
					}
				}

				placeFilerResults.count = tempList.size();
				placeFilerResults.values = tempList;
			} else {
				placeFilerResults.count = mGPlacesDataAL.size();
				placeFilerResults.values = mGPlacesDataAL;
			}

			return placeFilerResults;
		}

		@Override
		protected void publishResults(CharSequence constraint,
				FilterResults results) {
			filteredPlacesAL = (ArrayList<GooglePlaceData>) results.values;
			notifyDataSetChanged();
		}
	}
}
