package com.snapdealgallery.places.model;

public class GooglePlaceData {

	public String mPlaceIcon,mPlaceName,mLatitude,mLongitude;
	public String mPlaceId,mReference,mScope,mTypes,mVicinity;
	
}
