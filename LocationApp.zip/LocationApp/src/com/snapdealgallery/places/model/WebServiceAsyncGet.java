package com.snapdealgallery.places.model;

import java.net.URI;
import java.net.UnknownHostException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

/**
 * This class works for the background thread with HTTPGET method to retrieve
 * response and pass this response to OnWebServiceProcess interface for related
 * UI usage
 */
public class WebServiceAsyncGet extends AsyncTask<Void, Void, Void> {
	private String getUrl = null;
	private String getResult = null;
	private int receivedId;
	private OnWebServiceProcess interfaceListener = null;
	private boolean isSuccess, isDialog;

	ProgressDialog dialog;

	/**
	 * Constructor definition that will use in the activity to call the
	 * interface and server functionality
	 * 
	 * @param Activity
	 *            context
	 * @param web
	 *            service url
	 * @param activity
	 *            /process id
	 * @param OnWebServiceProcess
	 *            listener
	 * @param boolean to display dialog at the time of processing
	 */
	public WebServiceAsyncGet(Context context, String url, int id,
			OnWebServiceProcess listener, boolean isDialogDisplay) {
		// set the global values for the constructor parameters
		this.interfaceListener = listener;
		getUrl = url;
		receivedId = id;

		// progress dialog initialization
		isDialog = isDialogDisplay;
		this.dialog = new ProgressDialog(context);
		this.dialog.setMessage("Please wait.....");
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		// Run the progress dialog till we get response from server or receive
		// an error
		if (isDialog)
			dialog.show();
	}

	@Override
	protected Void doInBackground(Void... params) {
		HttpClient httpclient = new DefaultHttpClient();
		HttpGet request = new HttpGet();
		try {
			request.setURI(new URI(getUrl));

			// Execute HTTP Get Request
			HttpResponse response = httpclient.execute(request);
			Log.e("", "response code = "
					+ response.getStatusLine().getStatusCode());
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				getResult = EntityUtils.toString(entity);
				Log.i("", "Web service response = " + getResult + "\n" + entity);

			}
			isSuccess = true;

		} catch (UnknownHostException ex) {
			Log.e("", "Web service response UnknownHost error " + ex);
		} catch (Exception e) {
			Log.e("", "Web service response error " + e);
		}
		return null;

	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);
		if (interfaceListener != null) {
			interfaceListener.getServerValues(getResult, receivedId, isSuccess);
		} else {
			interfaceListener.setServerError(receivedId,
					"Error in interface attached");
		}

		if (this.dialog.isShowing()) {
			this.dialog.dismiss();
		}
	}

}
