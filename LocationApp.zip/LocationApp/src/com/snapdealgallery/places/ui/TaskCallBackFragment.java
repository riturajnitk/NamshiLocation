package com.snapdealgallery.places.ui;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Activity;
import android.app.Fragment;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class TaskCallBackFragment extends Fragment {

	private static final String TAG = "PlaceDetailsFragment";
	private TaskCallbacks mCallbacks;
	private DownloadFullImageAsyncTask mTask;
	private String mUrl;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setRetainInstance(true);

		mUrl = (String) getArguments().get("URL");
		Log.e(TAG, "##########  mPhotoRef  #########  " + mUrl);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		mTask = new DownloadFullImageAsyncTask();
		mTask.execute(mUrl);

		return super.onCreateView(inflater, container, savedInstanceState);
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mCallbacks = null;
	}

	class DownloadFullImageAsyncTask extends AsyncTask<String, Void, Bitmap> {

		public DownloadFullImageAsyncTask() {

		}

		@Override
		protected void onPreExecute() {

			if (mCallbacks != null) {
				mCallbacks.onPreExecute();
			}
		}

		@Override
		protected Bitmap doInBackground(String... mUrl) {

			Bitmap mBmp = null;
			try {
				URL murl = new URL(mUrl[0]);
				HttpURLConnection mConn = (HttpURLConnection) murl
						.openConnection();
				mConn.connect();
				InputStream is = mConn.getInputStream();
				mBmp = BitmapFactory.decodeStream(is);

			} catch (IOException e) {

			}
			return mBmp;
		}

		@Override
		protected void onCancelled() {
			if (mCallbacks != null) {
				mCallbacks.onCancelled();
			}
		}

		@Override
		protected void onPostExecute(Bitmap mBmp) {

			if (mCallbacks != null) {
				mCallbacks.onPostExecute(mBmp);
			}
		}
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		mCallbacks = (TaskCallbacks) activity;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

	}

	interface TaskCallbacks {
		void onPreExecute();

		void onProgressUpdate(int percent);

		void onCancelled();

		void onPostExecute(Bitmap mBmp);
	}
}
