package com.snapdealgallery.places.ui;

import java.util.ArrayList;

import org.json.JSONObject;

import android.app.ListFragment;
import android.app.SearchManager;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.SearchView.OnQueryTextListener;
import android.widget.Toast;

import com.sd.places.ui.R;
import com.snapdealgallery.googleplaces.util.PlaceDataParsing;
import com.snapdealgallery.googleplaces.util.Utils;
import com.snapdealgallery.places.model.AsynchronousAdapter;
import com.snapdealgallery.places.model.GooglePlaceData;
import com.snapdealgallery.places.model.OnWebServiceProcess;
import com.snapdealgallery.places.model.WebServiceAsyncGet;

public class GooglePlacesFragment extends ListFragment implements OnWebServiceProcess, LocationListener, OnQueryTextListener{

	
	protected static final String TAG = "GooglePlacesFragment";
	private AsynchronousAdapter adapter;
	private String mPlaceAPIKey = "AIzaSyCTrKJDtv50dEws0myX4WCsow0ZZSTY6JQ";
	private String mPlecesUrl = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?";
	private double mLatitude, mLongitude;
	private Location mLastLocation;
	private boolean gps_enabled, network_enabled;
	private LocationManager locationManager;
	private MenuItem mSearchMenuItem;
	private SearchView mSearchView;
	private Location mLocation;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		getCurrentLocation();
		setHasOptionsMenu(true);
		setRetainInstance(true);
	}
	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
	
		super.onViewCreated(view, savedInstanceState);
	}
	public void getCurrentLocation() {

		new Thread() {

			@Override
			public void run() {
				super.run();

				locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);

				try {
					gps_enabled = locationManager
							.isProviderEnabled(LocationManager.GPS_PROVIDER);
				} catch (Exception ex) {
				}
				try {
					network_enabled = locationManager
							.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
				} catch (Exception ex) {
				}
				if (gps_enabled) 
					mLocation = locationManager
						.getLastKnownLocation(LocationManager.GPS_PROVIDER);

				if(network_enabled)
					mLocation = locationManager
					.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
				
				if (mLocation != null) {
					
					Log.e(TAG, "#########  location  ##########");
					onLocationChanged(mLocation);
				}

			
			}
		}.start();

		if (gps_enabled) {
			locationManager.requestLocationUpdates(
					LocationManager.GPS_PROVIDER, 0, 0,
					GooglePlacesFragment.this);
		}
		
		if (network_enabled) {
			locationManager.requestLocationUpdates(
					LocationManager.NETWORK_PROVIDER, 0, 0,
					GooglePlacesFragment.this);
		}
		mHandle.sendEmptyMessage(1);
	}
	
	Handler mHandle = new Handler() {

		public void handleMessage(Message msg) {

			if (msg.what == 1) {

				if (mLastLocation != null) {

					mLatitude = mLastLocation.getLatitude();
					mLongitude = mLastLocation.getLongitude();
				} else {
					// only for testing purpose
					mLatitude = 28.535516;
					mLongitude = 77.3910226;
				}
				if (Utils.connectionAvailable(getActivity().getApplicationContext()) && gps_enabled) {

					String mUrl = mPlecesUrl + "location=" + mLatitude + ","
							+ mLongitude + "&radius=5000000&key="
							+ mPlaceAPIKey;
					Log.e(TAG, "###########  mUrl  ############### " + mUrl);
					new WebServiceAsyncGet(getActivity(), mUrl, 100,GooglePlacesFragment.this, false).execute();

				}

				else {
					Toast _toast = Toast.makeText(getActivity(),
							"No Data Connection and GPS disabled", Toast.LENGTH_LONG);
					_toast.setGravity(Gravity.CENTER_HORIZONTAL
							| Gravity.CENTER_VERTICAL, 0, 0);
					_toast.show();
				}

			}

		};
	};
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		return super.onCreateView(inflater, container, savedInstanceState);
	}
	

	@Override
	public void getServerValues(String response, int id, boolean isOk) {

		Log.e(TAG,
				"##############  getServerValues response ##############  "
						+ response);
		if (response != null) {

			new PaserAsynctask().execute(response);
		}

	}

	@Override
	public void setServerError(int id, String msg) {

	}

	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}
	
	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	    mSearchView.clearFocus();	
	}
	
	private class PaserAsynctask extends
			AsyncTask<String, Integer, ArrayList<GooglePlaceData>> {

		JSONObject jObject;

		@Override
		protected ArrayList<GooglePlaceData> doInBackground(String... jsonData) {

			ArrayList<GooglePlaceData> gPlacesAL = null;
			PlaceDataParsing mPlaceParse = new PlaceDataParsing();

			try {
				jObject = new JSONObject(jsonData[0]);

				/** Getting the parsed data as a List construct */
				gPlacesAL = mPlaceParse.getPlaces(jObject);

			} catch (Exception e) {
				Log.d("Exception", e.toString());
			}
			return gPlacesAL;
		}

		@Override
		protected void onPostExecute(ArrayList<GooglePlaceData> gPlacesAL) {

			if (gPlacesAL != null && gPlacesAL.size() > 0) {

				Log.e(TAG,
						"##############  gPlacesAL size ##############  "
								+ gPlacesAL.size());
				adapter = new AsynchronousAdapter(getActivity(), gPlacesAL);
				setListAdapter(adapter);
			}
		}
	}

	@Override
	public void onLocationChanged(Location location) {

		mLastLocation = location;
		//Toast.makeText(getActivity(),"lat "+ mLastLocation.getLatitude()+"Lon "+mLastLocation.getLongitude(),Toast.LENGTH_LONG).show();
		
		Log.e(TAG, "##############  mLatitude ##############  "
				+ mLastLocation.getLatitude());
		Log.e(TAG, "##############  mLongitude ##############  "
				+ mLastLocation.getLongitude());
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {

	}

	@Override
	public void onProviderEnabled(String provider) {

	}

	@Override
	public void onProviderDisabled(String provider) {

	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		
		inflater.inflate(R.menu.main, menu);
		
		SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
		mSearchMenuItem =  menu.findItem(R.id.action_search);
		mSearchView = (SearchView) 
				mSearchMenuItem.getActionView();
		mSearchView.setSearchableInfo(searchManager
				.getSearchableInfo(getActivity().getComponentName()));
		mSearchView.setOnQueryTextListener(this);
		super.onCreateOptionsMenu(menu, inflater);
	}
	@Override
	public boolean onQueryTextSubmit(String query) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean onQueryTextChange(String newText) {

		Log.e(TAG,"#########  onQueryTextChange   #########  " + newText);
		adapter.getFilter().filter(newText);
		adapter.notifyDataSetChanged();
		return true;
	}

}
