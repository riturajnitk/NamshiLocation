package com.snapdealgallery.places.ui;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.sd.places.ui.R;
import com.snapdealgallery.places.model.PinchZoom;
import com.snapdealgallery.places.model.PinchZoom.Anchor;

public class PlaceDetailsActivity extends Activity implements
		TaskCallBackFragment.TaskCallbacks {

	private ImageView mFullImage;
	private String mPhotoRef;
	private String mFullImageUrl;
	private ProgressDialog dialog;

	private static final String TAG_TASK_FRAGMENT = "task_fragment";
	private static final String TAG = "PlaceDetailsActivity";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.place_details);
		mPhotoRef = getIntent().getExtras().getString("PHOTOREF");

		dialog = new ProgressDialog(PlaceDetailsActivity.this);
		dialog.setMessage("Please wait.....");

		getActionBar().setDisplayHomeAsUpEnabled(true);
		FrameLayout fm = (FrameLayout) findViewById(R.id.fullImageparent);
		mFullImage = (ImageView) findViewById(R.id.fullimage);

		fm.setOnTouchListener(new PinchZoom(fm, mFullImage, Anchor.TOPLEFT));

		final DisplayMetrics displayMetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

		final int width = displayMetrics.widthPixels;

		mFullImageUrl = "https://maps.googleapis.com/maps/api/place/photo?maxwidth="
				+ width
				+ "&photoreference="
				+ mPhotoRef
				+ "+&key=AIzaSyCTrKJDtv50dEws0myX4WCsow0ZZSTY6JQ";

		FragmentManager mFragManager = getFragmentManager();
		TaskCallBackFragment mTaskFragment = (TaskCallBackFragment) mFragManager
				.findFragmentByTag(TAG_TASK_FRAGMENT);

		if (mTaskFragment == null) {
			mTaskFragment = new TaskCallBackFragment();
			Bundle b = new Bundle();
			b.putString("URL", mFullImageUrl);
			mTaskFragment.setArguments(b);
			mFragManager.beginTransaction()
					.add(mTaskFragment, TAG_TASK_FRAGMENT).commit();
		}

	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		// Respond to the action bar's Up/Home button
		case android.R.id.home:
			NavUtils.navigateUpFromSameTask(this);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onPreExecute() {

		Log.e("SUJIT", "##########  onPreExecute  #########  ");
		dialog.show();
	}

	@Override
	public void onProgressUpdate(int percent) {

	}

	@Override
	public void onCancelled() {

	}

	@Override
	public void onPostExecute(Bitmap mBmp) {

		Log.e(TAG, "##########  onPostExecute  #########  ");
		if (mBmp != null) {

			mFullImage.setImageBitmap(mBmp);
		}

		if (dialog.isShowing())
			dialog.dismiss();
	}

}
