package com.snapdealgallery.googleplaces.util;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.snapdealgallery.places.model.GooglePlaceData;

public class PlaceDataParsing {

	private ArrayList<GooglePlaceData> mGooglePlacesAl;

	public PlaceDataParsing() {

		mGooglePlacesAl = new ArrayList<GooglePlaceData>();
	}

	public ArrayList<GooglePlaceData> getPlaces(JSONObject jObject) {

		JSONArray jPlaces = null;
		try {
			jPlaces = jObject.getJSONArray("results");
		} catch (JSONException e) {
			e.printStackTrace();
		}

		for (int i = 0; i < jPlaces.length(); i++) {

			GooglePlaceData gPlaceData = new GooglePlaceData();

			JSONObject jPlace = null;
			try {
				jPlace = (JSONObject) jPlaces.get(i);
			} catch (JSONException e1) {
				e1.printStackTrace();
			}

			try {
				if (!jPlace.isNull("name")) {
					gPlaceData.mPlaceName = jPlace.getString("name");
				}
				if (!jPlace.isNull("icon")) {
					gPlaceData.mPlaceIcon = jPlace.getString("icon");
				}

				if (!jPlace.isNull("vicinity")) {
					gPlaceData.mVicinity = jPlace.getString("vicinity");
				}

				if(!jPlace.isNull("photos")){
					
					String mREf = jPlace.getJSONArray("photos").getJSONObject(0).getString("photo_reference");
					gPlaceData.mReference = mREf;
					
				}
					

				gPlaceData.mLatitude = jPlace.getJSONObject("geometry")
						.getJSONObject("location").getString("lat");
				gPlaceData.mLongitude = jPlace.getJSONObject("geometry")
						.getJSONObject("location").getString("lng");

			} catch (JSONException e) {
				e.printStackTrace();
			}

			mGooglePlacesAl.add(gPlaceData);
		}

		return mGooglePlacesAl;
	}
}